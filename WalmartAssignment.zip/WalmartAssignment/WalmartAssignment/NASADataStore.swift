//
//  NASADataStore.swift
//  WalmartAssignment
//
//  Created by Manoj on 17/06/21.
//

import Foundation



class NASADataStore {
    
    static let sharedInstance = NASADataStore()
    
    var date: String!
    var explanation: String!
    var title: String!


    private init() {}
    
    
    
}
