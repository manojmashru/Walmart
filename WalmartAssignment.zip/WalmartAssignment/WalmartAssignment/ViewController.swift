//
//  ViewController.swift
//  WalmartAssignment
//
//  Created by Manoj on 17/06/21.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var staticTitle: UILabel!
    @IBOutlet weak var sourceLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var imageTitle: UILabel!
    @IBOutlet weak var imageExplanation: UITextView!
    @IBOutlet weak var picOfTheDay: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if Reachability.isConnectedToNetwork(){
            print("Internet Connection Available!")
            self.getData()
        }else{
            print("Internet Connection not Available!")
            if let data = UserDefaults.standard.value(forKey: "response") as? [String:String] {
                print(data)
                self.dateLabel.text = data["date"]
                self.imageTitle.text = data["title"]
                self.imageExplanation.text = data["explanation"]
                self.picOfTheDay?.image = loadImageFromDocumentDirectory(nameOfImage: "saved")
            }
        }
    }

    func saveImageToDocumentDirectory(image: UIImage ) {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileName = "saved.png" // name of the image to be saved
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        if let data = image.jpegData(compressionQuality: 1.0),!FileManager.default.fileExists(atPath: fileURL.path){
            do {
                try data.write(to: fileURL)
                print("file saved")
            } catch {
                print("error saving file:", error)
            }
        }
    }

    func loadImageFromDocumentDirectory(nameOfImage : String) -> UIImage {
        let nsDocumentDirectory = FileManager.SearchPathDirectory.documentDirectory
        let nsUserDomainMask = FileManager.SearchPathDomainMask.userDomainMask
        let paths = NSSearchPathForDirectoriesInDomains(nsDocumentDirectory, nsUserDomainMask, true)
        if let dirPath = paths.first{
            let imageURL = URL(fileURLWithPath: dirPath).appendingPathComponent(nameOfImage)
            let image    = UIImage(contentsOfFile: imageURL.path)
            return image!
        }
        return UIImage.init(named: "saved.png")!
    }

    func clearTempFolder() {
        let fileManager = FileManager.default
        let tempFolderPath = NSTemporaryDirectory()
        do {
            let filePaths = try fileManager.contentsOfDirectory(atPath: tempFolderPath)
            for filePath in filePaths {
                try fileManager.removeItem(atPath: tempFolderPath + filePath)
            }
        } catch {
            print("Could not clear temp folder: \(error)")
        }
    }

    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }


    func getData(){
        NASAAPIClient.getDataFromAPI { (data) in
       
          NASAAPIClient.downloadImage(at: data["url"]!, completion: { (success, image) in
              
              if success == true {
                  print("got image data from URL")
                  DispatchQueue.main.async {
                    self.picOfTheDay.image = image
                    self.dateLabel.text = "\(data["date"]!)"
                    self.imageTitle.text = "\(data["title"]!)"
                    self.imageExplanation.text = "\(data["explanation"]!)"
                    self.clearTempFolder()
                    self.saveImageToDocumentDirectory(image: image!)
                    UserDefaults.standard.removeObject(forKey: "response")
                    UserDefaults.standard.setValue(data, forKey: "response")
                  }
                 
              } else {
                  print ("Error getting image")
              }
      
              
          })
          
          }

    }


}

